CREATE DATABASE IF NOT EXISTS `sos`;

USE sos;

DROP TABLE IF EXISTS `client_list`;

CREATE TABLE `client_list` (
  `client_id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` text NOT NULL,
  `lastname` text NOT NULL,
  `middlename` text NOT NULL,
  `age` int(3) NOT NULL,
  `address` text NOT NULL,
  `device_id` varchar(13) NOT NULL,
  PRIMARY KEY (`client_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `client_list` VALUES("4","Khiana","Padilla","Ignacio","22","Baler Aurora","+639163218023");
INSERT INTO `client_list` VALUES("5","Baldo","Macho","The","21","Maria Aurora, Aurora","+639269372574");
INSERT INTO `client_list` VALUES("6","jobert","simbre","asda","22","Purok 6 Brgy. Buhangin Baler Aurora","+639163218023");



DROP TABLE IF EXISTS `crime_list`;

CREATE TABLE `crime_list` (
  `crime_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `coordinates` text NOT NULL,
  `municipality` text NOT NULL DEFAULT 'Not Yet Responded',
  `address` text NOT NULL DEFAULT 'Not Yet Responded',
  `date` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` int(1) DEFAULT 0,
  PRIMARY KEY (`crime_id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `crime_list` VALUES("1","Khiana Ignacio Padilla","15.7718570,121.5542300","Baler","buhangin","2023-12-05 05:00:00","2");
INSERT INTO `crime_list` VALUES("31","Khiana Ignacio Padilla","15.7718570,121.5542300","Baler","Not Yet Responded","2023-12-11 13:26:28","0");
INSERT INTO `crime_list` VALUES("32","Khiana Ignacio Padilla","15.7718570,121.5542300","Baler","Brgy.Buhangin","2023-12-11 13:26:28","2");



DROP TABLE IF EXISTS `logs`;

CREATE TABLE `logs` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `user_email` text NOT NULL,
  `action` text NOT NULL,
  `log_date` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`log_id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `logs` VALUES("5","1","admin@access.com","Backup the database named backup-sos-20230824_115532.sql.gz","2023-08-24 00:00:00");
INSERT INTO `logs` VALUES("6","1","admin@access.com","Backup the database named backup-sos-20230824_115609.sql.gz","2023-08-24 00:00:00");
INSERT INTO `logs` VALUES("7","1","admin@access.com","Restore the database using backup-sos-20230824_115636.sql.gz","2023-08-25 00:00:00");
INSERT INTO `logs` VALUES("8","1","admin@access.com","Backup the database named backup-sos-20230825_080758.sql.gz","2023-08-25 00:00:00");
INSERT INTO `logs` VALUES("9","1","admin@access.com","Backup the database named backup-sos-20230825_160422.sql.gz","2023-08-25 00:00:00");
INSERT INTO `logs` VALUES("10","1","admin@access.com","Restore the database using backup-sos-20230825_161038.sql.gz","2023-10-07 00:00:00");
INSERT INTO `logs` VALUES("11","1","admin@access.com","Backup the database named backup-sos-20231020_114904.sql.gz","2023-10-20 00:00:00");
INSERT INTO `logs` VALUES("12","1","admin@access.com","Backup the database named backup-sos-October_21_2023_11_47_pm.sql.gz","2023-10-21 23:47:22");
INSERT INTO `logs` VALUES("13","1","admin@access.com","Backup the database named backup-sos-October_21_2023_11-49_pm.sql.gz","2023-10-21 23:49:21");
INSERT INTO `logs` VALUES("14","1","admin@access.com","Backup the database named backup-sos-October_21_2023_11-53_pm.sql.gz","2023-10-21 23:53:49");
INSERT INTO `logs` VALUES("15","1","admin@access.com","Restore the database using backup-sos-October_21_2023_11-53_pm.sql.gz","2023-10-21 23:57:57");
INSERT INTO `logs` VALUES("16","1","admin@access.com","Backup the database named backup-sos-October_22_2023_12-31_am.sql.gz","2023-10-22 00:31:28");
INSERT INTO `logs` VALUES("17","1","admin@access.com","Logged to the system","2023-12-11 14:35:59");
INSERT INTO `logs` VALUES("18","1","admin@access.com","Logged to the system","2023-12-11 19:31:27");
INSERT INTO `logs` VALUES("19","1","admin@access.com","Logged to the system","2023-12-11 21:39:46");
INSERT INTO `logs` VALUES("20","1","admin@access.com","Logged to the system","2023-12-12 00:15:21");
INSERT INTO `logs` VALUES("21","1","admin@access.com","Logged to the system","2023-12-12 00:20:03");
INSERT INTO `logs` VALUES("22","1","admin@access.com","Backup the database named backup-sos-December_12_2023_5-23_am.sql.gz","2023-12-12 05:23:45");



DROP TABLE IF EXISTS `reports`;

CREATE TABLE `reports` (
  `report_id` int(11) NOT NULL AUTO_INCREMENT,
  `crime_id` int(11) NOT NULL,
  `victim_name` text NOT NULL,
  `reporting_officer` text DEFAULT NULL,
  `address` text DEFAULT NULL,
  `incident` text DEFAULT NULL,
  `details` text DEFAULT NULL,
  `actions_taken` text DEFAULT NULL,
  `summary` text DEFAULT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp(),
  `audio` text DEFAULT NULL,
  PRIMARY KEY (`report_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `reports` VALUES("1","1","Khiana Ignacio Padilla","jobert simbre","buhangin","asdas","asdas","asdas","adas","2023-12-11 14:36:40","");
INSERT INTO `reports` VALUES("4","31","Khiana Ignacio Padilla",NULL,NULL,NULL,NULL,NULL,NULL,"2023-12-11 21:58:34","evidence_for_case_no_31.mp3");
INSERT INTO `reports` VALUES("5","32","Khiana Ignacio Padilla","asdasd","Brgy.Buhangin","asda","asda","asd","asda","2023-12-12 00:01:33",NULL);



DROP TABLE IF EXISTS `test`;

CREATE TABLE `test` (
  `test_id` int(11) NOT NULL AUTO_INCREMENT,
  `messages` text NOT NULL,
  `phone` varchar(13) NOT NULL,
  PRIMARY KEY (`test_id`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `test` VALUES("44","15.7718570,121.5542300\n","+639163218023");
INSERT INTO `test` VALUES("45","15.7718570,121.5542300\n","+639163218023");



DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `email` text NOT NULL,
  `password` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `privilege` text NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `users` VALUES("1","admin@access.com","$2y$10$HPTgcJcVQY6VOwmojTkirecrhY.lMctVUx/VCVAjgGkLbmZkJYF.G","2023-08-10 02:27:20","2023-08-10 02:27:20","$2y$10$qnvd1wz5EZvhYSKJc0j3.uqURn59HnNN7FogenNYqt9yk8/0MsCJO");
