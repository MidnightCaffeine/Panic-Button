CREATE DATABASE IF NOT EXISTS `sos`;

USE sos;

DROP TABLE IF EXISTS `client_list`;

CREATE TABLE `client_list` (
  `client_id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` text NOT NULL,
  `lastname` text NOT NULL,
  `middlename` text NOT NULL,
  `age` int(3) NOT NULL,
  `address` text NOT NULL,
  `device_id` varchar(13) NOT NULL,
  PRIMARY KEY (`client_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `client_list` VALUES("4","adas","asdas","yree","122","Baler Aurora","09163218023");
INSERT INTO `client_list` VALUES("5","asdw","fvcx","wqe","21","Maria Aurora, Aurora","2");



DROP TABLE IF EXISTS `crime_list`;

CREATE TABLE `crime_list` (
  `crime_id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` text NOT NULL,
  `lastname` text NOT NULL,
  `middlename` text NOT NULL,
  `coordinates` text NOT NULL,
  `municipality` text NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp(),
  `time` time NOT NULL DEFAULT current_timestamp(),
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`crime_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `crime_list` VALUES("1","dasd","asdas","fas","15.7718570,121.5542300","Baler","2023-10-07","05:20:25","0");



DROP TABLE IF EXISTS `logs`;

CREATE TABLE `logs` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `user_email` text NOT NULL,
  `action` text NOT NULL,
  `log_date` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`log_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `logs` VALUES("5","1","admin@access.com","Backup the database named backup-sos-20230824_115532.sql.gz","2023-08-24 00:00:00");
INSERT INTO `logs` VALUES("6","1","admin@access.com","Backup the database named backup-sos-20230824_115609.sql.gz","2023-08-24 00:00:00");
INSERT INTO `logs` VALUES("7","1","admin@access.com","Restore the database using backup-sos-20230824_115636.sql.gz","2023-08-25 00:00:00");
INSERT INTO `logs` VALUES("8","1","admin@access.com","Backup the database named backup-sos-20230825_080758.sql.gz","2023-08-25 00:00:00");
INSERT INTO `logs` VALUES("9","1","admin@access.com","Backup the database named backup-sos-20230825_160422.sql.gz","2023-08-25 00:00:00");
INSERT INTO `logs` VALUES("10","1","admin@access.com","Restore the database using backup-sos-20230825_161038.sql.gz","2023-10-07 00:00:00");
INSERT INTO `logs` VALUES("11","1","admin@access.com","Backup the database named backup-sos-20231020_114904.sql.gz","2023-10-20 00:00:00");
INSERT INTO `logs` VALUES("12","1","admin@access.com","Backup the database named backup-sos-October_21_2023_11_47_pm.sql.gz","2023-10-21 23:47:22");



DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `email` text NOT NULL,
  `password` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `privilege` text NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `users` VALUES("1","admin@access.com","$2y$10$HPTgcJcVQY6VOwmojTkirecrhY.lMctVUx/VCVAjgGkLbmZkJYF.G","2023-08-10 02:27:20","2023-08-10 02:27:20","$2y$10$qnvd1wz5EZvhYSKJc0j3.uqURn59HnNN7FogenNYqt9yk8/0MsCJO");
