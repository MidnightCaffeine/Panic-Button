CREATE DATABASE IF NOT EXISTS `sos`;

USE sos;

DROP TABLE IF EXISTS `client_list`;

CREATE TABLE `client_list` (
  `client_id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` text NOT NULL,
  `lastname` text NOT NULL,
  `middlename` text NOT NULL,
  `age` int(3) NOT NULL,
  `address` text NOT NULL,
  `device_id` int(11) NOT NULL,
  PRIMARY KEY (`client_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `client_list` VALUES("4","adas","asdas","yree","122","Purok 6 Brgy. Buhangin Baler Aurora","1");
INSERT INTO `client_list` VALUES("5","asdw","fvcx","wqe","21","Purok 6 Brgy. Buhangin Baler Aurora","2");



DROP TABLE IF EXISTS `logs`;

CREATE TABLE `logs` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `user_email` text NOT NULL,
  `action` text NOT NULL,
  `log_date` date NOT NULL DEFAULT current_timestamp(),
  `log_time` time NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`log_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `logs` VALUES("5","1","admin@access.com","Backup the database named backup-sos-20230824_115532.sql.gz","2023-08-24","11:55:32");
INSERT INTO `logs` VALUES("6","1","admin@access.com","Backup the database named backup-sos-20230824_115609.sql.gz","2023-08-24","11:56:09");
INSERT INTO `logs` VALUES("7","1","admin@access.com","Restore the database using backup-sos-20230824_115636.sql.gz","2023-08-25","08:04:37");
INSERT INTO `logs` VALUES("8","1","admin@access.com","Backup the database named backup-sos-20230825_080758.sql.gz","2023-08-25","08:07:58");



DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `email` text NOT NULL,
  `password` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `privilege` text NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `users` VALUES("1","admin@access.com","$2y$10$HPTgcJcVQY6VOwmojTkirecrhY.lMctVUx/VCVAjgGkLbmZkJYF.G","2023-08-09 11:27:20","2023-08-09 11:27:20","$2y$10$qnvd1wz5EZvhYSKJc0j3.uqURn59HnNN7FogenNYqt9yk8/0MsCJO");
